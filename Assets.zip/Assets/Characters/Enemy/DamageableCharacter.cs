﻿using Assets.Interfaces;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class DamageableCharacter : MonoBehaviour, IDamageable
{
    public GameObject healthText;
    public bool disableSimulation = false;
    Animator animator;
    Rigidbody2D rb;
    Collider2D phisicCollider;
    public bool canTurnInvincible = false;
    public float invincibilityTime = 0.3f;
    bool IsAlive = true;

    private float invincibleTimeElapsed = 0f;
    private void Start()
    {
        animator = GetComponent<Animator>();
        animator.SetBool("IsAlive", IsAlive);
        rb = GetComponent<Rigidbody2D>();
        phisicCollider = GetComponent<Collider2D>();
    }
    public float Health
    {
        get
        {
            return _health;
        }
        set
        {
            if (value < _health)
            {
                Hit();
               
            }

            _health = value;

            if (_health <= 0)
            {
                Defeated();
            }
        }
    }

    public bool Targetable {
        get => _target;
        set
        {
            _target = value;
            if (disableSimulation) 
                rb.simulated = false;
            phisicCollider.enabled = value;
        }
    }

    public bool Invincible { 
        get => _invincible;
        set
        {
            _invincible = value;
            if(_invincible)
                invincibleTimeElapsed = 0;
        }
    }

    public bool _invincible = false;

    float _health = 3;
    bool _target = true;

  

    public void Defeated()
    {
        animator.SetBool("IsAlive", false);
        Targetable = false;
    }
    public void Hit()
    {
        animator.SetTrigger("Hit");
        RectTransform textTransform = Instantiate(healthText).GetComponent<RectTransform>();
        textTransform.transform.position = Camera.main.WorldToScreenPoint(gameObject.transform.position);

        Canvas canvas = GameObject.FindObjectOfType<Canvas>();
        textTransform.SetParent(canvas.transform);
    }
    public void RemoveObject()
    {
        Destroy(gameObject);
    }

    public void OnHit(float damage, Vector2 knockback)
    {
        if (!Invincible)
        {
            Health -= damage;
            rb.AddForce(knockback, ForceMode2D.Impulse);
            if (canTurnInvincible)
            {
                Invincible = true;
            }
        }
    }

    public void OnHit(float damage)
    {
        if (!Invincible)
        {
            Health -= damage;
            if (canTurnInvincible)
            {
                Invincible = true;
            }
        }
    }

    public void FixedUpdate()
    {
        if (Invincible){
            invincibleTimeElapsed += Time.deltaTime;
            if(invincibleTimeElapsed > invincibilityTime)
            {
                Invincible = false;
            }
        }
    }
}
