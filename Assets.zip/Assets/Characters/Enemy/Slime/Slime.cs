using Assets.Interfaces;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slime : MonoBehaviour
{
    public float damage = 1f;
    public float knockBackForce = 100f;

    public DetectionZone detectionZone;

    public float speed = 500f;

    Rigidbody2D rb;
    DamageableCharacter damageableCharacter;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        damageableCharacter = GetComponent<DamageableCharacter>();
    }
    private void FixedUpdate()
    {
        int count = detectionZone.detectedObject.Count;
        if (damageableCharacter.Targetable &&count > 0)
        {
            Vector2 direction = (detectionZone.detectedObject[0].transform.position - transform.position).normalized;
            rb.AddForce(direction * speed * Time.deltaTime);
        }
    }
    public void OnCollisionEnter2D(Collision2D col)
    {
        Collider2D collider = col.collider;
        IDamageable damageable = collider.GetComponent<IDamageable>();
        if(damageable != null)
        {
            IDamageable damagableObject = collider.GetComponent<IDamageable>();
            if (damagableObject != null)
            {
                Vector2 direction = (Vector2)(collider.transform.position - transform.position).normalized;
                Vector2 knockBack = direction * knockBackForce;
                damagableObject.OnHit(damage, knockBack);
            }
            else
            {
                Debug.LogWarning("IDamagable is null");
            }
        }
    }
}
