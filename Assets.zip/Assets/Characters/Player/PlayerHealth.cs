using Assets.Interfaces;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealth : MonoBehaviour { 

    public float _health = 3f;
}
