using Assets.Interfaces;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class SwordAttack : MonoBehaviour
{
    public float swordDamage = 2f;
    public float knockBackForce = 15f;

    public Collider2D swordCollidder;
    Vector2 rightAttackOffset;
    private void Start()
    {
        if (swordCollidder == null)
            Debug.LogWarning("Sword Collider no set");
        rightAttackOffset = transform.position;
    }
 
    public void AttackRight()
    {
        swordCollidder.enabled = true;
        transform.localPosition = rightAttackOffset;
    }

    public void AttackLeft()
    {
        swordCollidder.enabled = true;
        transform.localPosition = new Vector3(rightAttackOffset.x * -1, rightAttackOffset.y);
    }

   
    public void StopAttack()
    {
        swordCollidder.enabled = false;
    }

    private void OnTriggerEnter2D(Collider2D collider)
    {
        IDamageable damagableObject = collider.GetComponent<IDamageable>();
        if (damagableObject != null)
        {
            Vector3 parentPosition = transform.parent.position;

            Vector2 direction = (Vector2)(collider.transform.position - parentPosition).normalized;
            Vector2 knockBack = direction * knockBackForce;
            damagableObject.OnHit(swordDamage, knockBack);
        }
        /* if (collider.tag == "Enemy")
         {
             Enemy enemy = collider.GetComponent<Enemy>();
             if(enemy != null)
             {
                 enemy.Health -= swordDamage;
             }
         }*/

    }
}
