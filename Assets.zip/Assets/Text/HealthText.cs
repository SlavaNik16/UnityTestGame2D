using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class HealthText : MonoBehaviour
{
    public float timeToLive = 0.5f;
    public TextMeshProUGUI textMeshPro;
    public float speed = 50f;
    public Vector3 direction = new Vector3(0, 1, 0);
    float timeElapsed = 0.0f;
    RectTransform rTransform;
    Color color;
    private void Start()
    {
        color = textMeshPro.color;
        rTransform = GetComponent<RectTransform>();
    }
    private void Update()
    {
        timeElapsed += Time.deltaTime;
        rTransform.position += direction * speed * Time.deltaTime;
        textMeshPro.color = new Color(color.r, color.g, color.b, 1 - (timeElapsed / timeToLive));
        if(timeElapsed > timeToLive)
        {
            Destroy(gameObject);
        }
    }
}
